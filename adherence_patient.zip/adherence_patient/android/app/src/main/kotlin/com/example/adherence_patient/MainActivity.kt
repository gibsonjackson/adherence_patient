package com.example.adherence_patient

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
